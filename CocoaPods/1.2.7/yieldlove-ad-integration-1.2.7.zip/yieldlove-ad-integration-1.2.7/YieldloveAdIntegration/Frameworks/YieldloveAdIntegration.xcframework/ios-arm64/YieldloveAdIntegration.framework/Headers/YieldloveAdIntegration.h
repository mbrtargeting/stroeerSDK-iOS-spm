//
//  YieldloveAdIntegration.h
//  YieldloveAdIntegration
//
//  Created by Marcel Klínek on 05.10.2021.
//

#import <Foundation/Foundation.h>

// Public umbrella for the module:
#import <YieldloveAdIntegration/SPTIabTCFConstants.h>
#import <YieldloveAdIntegration/SPTIabTCFUtils.h>
#import <YieldloveAdIntegration/SPTIabTCFv1Types.h>
#import <YieldloveAdIntegration/SPTIabTCFv2Types.h>
#import <YieldloveAdIntegration/SPTIabPublisherRestriction.h>
#import <YieldloveAdIntegration/SPTIabTCFModel.h>
#import <YieldloveAdIntegration/SPTIabTCStringParser.h>
#import <YieldloveAdIntegration/SPTIabTCFv1StorageProtocol.h>
#import <YieldloveAdIntegration/SPTIabTCFv1StorageUserDefaults.h>
#import <YieldloveAdIntegration/SPTIabTCFv2StorageProtocol.h>
#import <YieldloveAdIntegration/SPTIabTCFv2StorageUserDefaults.h>
#import <YieldloveAdIntegration/SPTIabTCFApi.h>

// GCDWebServer (embedded)
#import <YieldloveAdIntegration/GCDWebServerHTTPStatusCodes.h>
#import <YieldloveAdIntegration/GCDWebServerFunctions.h>

#import <YieldloveAdIntegration/GCDWebServerConnection.h>
#import <YieldloveAdIntegration/GCDWebServerRequest.h>
#import <YieldloveAdIntegration/GCDWebServerDataRequest.h>
#import <YieldloveAdIntegration/GCDWebServerFileRequest.h>
#import <YieldloveAdIntegration/GCDWebServerMultiPartFormRequest.h>
#import <YieldloveAdIntegration/GCDWebServerURLEncodedFormRequest.h>

#import <YieldloveAdIntegration/GCDWebServerResponse.h>
#import <YieldloveAdIntegration/GCDWebServerDataResponse.h>
#import <YieldloveAdIntegration/GCDWebServerErrorResponse.h>
#import <YieldloveAdIntegration/GCDWebServerFileResponse.h>
#import <YieldloveAdIntegration/GCDWebServerStreamedResponse.h>

#import <YieldloveAdIntegration/GCDWebServer.h>

//! Project version number for YieldloveAdIntegration.
FOUNDATION_EXPORT double YieldloveAdIntegrationVersionNumber;

//! Project version string for YieldloveAdIntegration.
FOUNDATION_EXPORT const unsigned char YieldloveAdIntegrationVersionString[];
